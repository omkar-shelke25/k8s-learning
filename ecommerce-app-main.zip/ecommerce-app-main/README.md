# Ecommerce App

This is a sample e-commerce application with frontend, backend, and Kubernetes manifests.